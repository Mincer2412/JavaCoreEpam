package travelAgency.user.search;

import travelAgency.common.buisness.search.BaseSearchCondition;

public class UserSearchCondition extends BaseSearchCondition<Long> {


}
