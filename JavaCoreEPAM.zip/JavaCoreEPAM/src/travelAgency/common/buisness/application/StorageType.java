package travelAgency.common.buisness.application;

public enum StorageType {
    MEMORY_ARRAY,
    MEMORY_COLLECTION
}
