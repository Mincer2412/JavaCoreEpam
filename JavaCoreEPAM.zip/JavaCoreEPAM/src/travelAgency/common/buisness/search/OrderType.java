package travelAgency.common.buisness.search;

public enum  OrderType {
    SIMPLE, COMPLEX
}
