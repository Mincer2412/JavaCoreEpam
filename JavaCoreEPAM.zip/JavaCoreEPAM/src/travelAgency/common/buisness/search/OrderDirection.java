package travelAgency.common.buisness.search;

public enum OrderDirection {
    ASC, DESC
}
