package travelAgency.common.buisness.repo;

public class makePackageAllowed {

}
