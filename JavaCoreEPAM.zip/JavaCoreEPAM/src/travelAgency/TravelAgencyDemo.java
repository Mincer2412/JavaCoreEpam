package travelAgency;


public class TravelAgencyDemo {

    private static class Application {

    }
}
