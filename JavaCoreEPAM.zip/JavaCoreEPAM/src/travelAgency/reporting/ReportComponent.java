package travelAgency.reporting;

import java.io.File;

public interface ReportComponent {
    File generateReport() throws Exception;
}
